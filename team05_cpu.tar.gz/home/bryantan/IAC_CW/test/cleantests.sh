#!/bin/bash
set -eou pipefail

rm /home/bryantan/IAC_CW/test/tb_outputs/*