TODO:
- create tb for JR
- create tb for ADDU
- create tb for ADDIU
- create tb for LW
- create tb for SW