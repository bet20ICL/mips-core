opcodes = {
    "addiu": (1, ),

}

